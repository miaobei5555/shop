<!-- dialog -->
<div id="dialog" class="weui_dialog_confirm" style="display: none;">
  <div class="weui_mask"></div>
  <div class="weui_dialog">
    <div class="weui_dialog_hd">
      <strong class="weui_dialog_title">提示</strong>
    </div>
    <div class="weui_dialog_bd">您确定删除该条记录?
      <br/>
    </div>
    <div class="weui_dialog_ft">
      <a href="javascript:;" class="weui_btn_dialog default">取消</a>
      <a href="javascript:;" class="weui_btn_dialog primary">确定</a>
    </div>
  </div>
</div>
